import React, { useEffect, useMemo, useRef, useState } from 'react'
import JSZip from 'jszip'
import { Activity, ArrowDownToLine, ArrowUpRight, Bot, Check, ChevronDown, CircleHelp, Code2, Copy, Eye, EyeOff, FileCode2, FolderPlus, Image as ImageIcon, KeyRound, LoaderCircle, LogIn, LogOut, Menu, MessageSquare, Mic, MicOff, Moon, Paperclip, Plus, Rocket, Send, Settings2, ShieldCheck, Sparkles, SquarePen, Trash2, Volume2, WandSparkles, X } from 'lucide-react'
import { chatCompletion, testConnection, generateImage } from './lib/ai'
import { sendEmailOtp, signInWithPassword, signOut, signUpWithPassword, supabase, supabaseConfigured } from './lib/supabase'

const DEFAULTS = { baseUrl: '', apiKey: '', model: '', temperature: '0.7', maxTokens: '2048', imageEndpoint: '', imageModel: '' }
const loadSettings = () => { try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('navin-settings') || '{}') } } catch { return DEFAULTS } }
const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
const starterPrompts = [
  { icon: Code2, title: 'Build a website', desc: 'Create a responsive landing page', prompt: 'Help me plan and generate a responsive website. First ask what it should do, then generate complete code files.' },
  { icon: WandSparkles, title: 'Write code', desc: 'Debug or explain a code snippet', prompt: 'Help me write clean, working code. Ask for missing requirements before writing the solution.' },
  { icon: ImageIcon, title: 'Create an image', desc: 'Open the image studio', action: 'image' },
  { icon: Rocket, title: 'Plan a project', desc: 'Turn an idea into clear steps', prompt: 'Help me plan a real software project with milestones, architecture, files, tests, and deployment steps.' }
]
function Logo({ small = false }) { return <img className={small ? 'logo small' : 'logo'} src="/navin-logo.svg" alt="Navin AI" /> }
function App() {
  const [settings, setSettings] = useState(loadSettings)
  const [active, setActive] = useState('chat')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const [authMode, setAuthMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [authMessage, setAuthMessage] = useState('')
  const [session, setSession] = useState(null)
  const [draft, setDraft] = useState('')
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState('')
  const [toast, setToast] = useState('')
  const [apiTest, setApiTest] = useState('')
  const [showKey, setShowKey] = useState(false)
  const [messages, setMessages] = useState([])
  const [chats, setChats] = useState(() => { try { return JSON.parse(localStorage.getItem('navin-chats') || '[]') } catch { return [] } })
  const [currentChat, setCurrentChat] = useState(null)
  const [imagePrompt, setImagePrompt] = useState('')
  const [imageResult, setImageResult] = useState('')
  const [imageBusy, setImageBusy] = useState(false)
  const [imageError, setImageError] = useState('')
  const [voiceOn, setVoiceOn] = useState(false)
  const [voiceSupported, setVoiceSupported] = useState(Boolean(window.SpeechRecognition || window.webkitSpeechRecognition))
  const [builderPrompt, setBuilderPrompt] = useState('')
  const [projectName, setProjectName] = useState('My AI Project')
  const [projectFiles, setProjectFiles] = useState([])
  const [selectedFile, setSelectedFile] = useState('')
  const [builderLog, setBuilderLog] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const [showMobileSidebar, setShowMobileSidebar] = useState(false)
  const recognitionRef = useRef(null)
  const bottomRef = useRef(null)
  const activeChat = useMemo(() => chats.find(c => c.id === currentChat), [chats, currentChat])

  useEffect(() => { localStorage.setItem('navin-settings', JSON.stringify(settings)) }, [settings])
  useEffect(() => { localStorage.setItem('navin-chats', JSON.stringify(chats)) }, [chats])
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }) }, [messages, busy])
  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setSession(session))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => () => { recognitionRef.current?.stop?.(); window.speechSynthesis?.cancel?.() }, [])

  const notify = (message) => { setToast(message); window.setTimeout(() => setToast(''), 3200) }
  const updateSetting = (key, value) => setSettings(old => ({ ...old, [key]: value }))
  const newChat = () => { setCurrentChat(null); setMessages([]); setDraft(''); setActive('chat'); setSidebarOpen(false) }
  const openChat = (chat) => { setCurrentChat(chat.id); setMessages(chat.messages || []); setActive('chat'); setSidebarOpen(false) }
  const persistMessages = (next, id = currentChat) => {
    const chatId = id || makeId()
    const firstUser = next.find(m => m.role === 'user')?.content || 'New conversation'
    setCurrentChat(chatId)
    setChats(old => {
      const found = old.some(c => c.id === chatId)
      const item = { id: chatId, title: firstUser.slice(0, 38), updatedAt: new Date().toISOString(), messages: next }
      return found ? old.map(c => c.id === chatId ? item : c).sort((a,b) => b.updatedAt.localeCompare(a.updatedAt)) : [item, ...old].slice(0, 60)
    })
  }
  const sendMessage = async (content = draft) => {
    const prompt = content.trim()
    if (!prompt || busy) return
    if (!settings.baseUrl || !settings.model) { setSettingsOpen(true); setToast('Pehle Settings mein apni API URL aur model bharo.'); return }
    const userMsg = { id: makeId(), role: 'user', content: prompt, time: new Date().toISOString() }
    const next = [...messages, userMsg]
    setMessages(next); setDraft(''); setBusy(true); setStatus('Connecting to your configured AI API…')
    persistMessages(next)
    try {
      const answer = await chatCompletion({ ...settings, messages: next.map(m => ({ role: m.role, content: m.content })) })
      const complete = [...next, { id: makeId(), role: 'assistant', content: answer, time: new Date().toISOString() }]
      setMessages(complete); persistMessages(complete)
    } catch (e) {
      const failed = [...next, { id: makeId(), role: 'assistant', content: `API error: ${e.message}`, error: true, time: new Date().toISOString() }]
      setMessages(failed); persistMessages(failed)
    } finally { setBusy(false); setStatus('') }
  }
  const runApiTest = async () => {
    setApiTest('Testing your API…')
    try { const result = await testConnection(settings); setApiTest(`Connected. Response: ${result}`) }
    catch (e) { setApiTest(`Connection failed: ${e.message}`) }
  }
  const startVoice = () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!Recognition) { notify('Is browser mein speech recognition available nahi hai. Chrome desktop try karo.'); return }
    if (voiceOn) { recognitionRef.current?.stop(); setVoiceOn(false); return }
    const rec = new Recognition()
    rec.lang = 'hi-IN'; rec.interimResults = true; rec.continuous = false
    rec.onresult = (event) => { const text = Array.from(event.results).map(r => r[0].transcript).join(''); setDraft(text) }
    rec.onerror = (event) => { notify(`Voice input error: ${event.error}`); setVoiceOn(false) }
    rec.onend = () => setVoiceOn(false)
    recognitionRef.current = rec
    try { rec.start(); setVoiceOn(true) } catch (e) { notify(e.message) }
  }
  const speak = (text) => {
    if (!('speechSynthesis' in window)) { notify('Text-to-speech is not supported in this browser.'); return }
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = /[अ-ह]/.test(text) ? 'hi-IN' : 'en-US'
    window.speechSynthesis.speak(utterance)
  }
  const runImage = async () => {
    if (!imagePrompt.trim()) return
    if (!settings.imageEndpoint) { setSettingsOpen(true); setImageError('Settings mein compatible Image API endpoint configure karo.'); return }
    setImageBusy(true); setImageError(''); setImageResult('')
    try {
      const url = await generateImage({ endpoint: settings.imageEndpoint, apiKey: settings.apiKey, model: settings.imageModel, prompt: imagePrompt })
      setImageResult(url)
    } catch (e) { setImageError(e.message) } finally { setImageBusy(false) }
  }
  const generateProject = async () => {
    const prompt = builderPrompt.trim()
    if (!prompt) return
    if (!settings.baseUrl || !settings.model) { setSettingsOpen(true); setBuilderLog('Pehle AI API settings configure karo.'); return }
    setBusy(true); setBuilderLog('Requesting code generation from your configured AI API…')
    const instruction = `You are a practical software code generator. Create a small but complete project named "${projectName}". User requirements: ${prompt}\nReturn ONLY valid JSON in this exact shape: {"files":[{"path":"index.html","content":"..."}]}. Include all required source files, no markdown fences, avoid secrets, and do not claim files were tested unless they were.`
    try {
      const raw = await chatCompletion({ ...settings, messages: [{ role: 'system', content: 'Return only valid JSON. Generate runnable code files.' }, { role: 'user', content: instruction }], maxTokens: Math.max(Number(settings.maxTokens) || 2048, 4096), temperature: 0.25 })
      const cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')
      const parsed = JSON.parse(cleaned)
      if (!Array.isArray(parsed.files) || !parsed.files.length) throw new Error('AI response mein files array nahi mili.')
      const safe = parsed.files.filter(f => typeof f.path === 'string' && typeof f.content === 'string' && !f.path.startsWith('/') && !f.path.includes('..')).slice(0, 80)
      if (!safe.length) throw new Error('No safe files returned.')
      setProjectFiles(safe); setSelectedFile(safe[0].path); setBuilderLog(`${safe.length} files generated. Code ko review aur test karna zaroori hai; ye automatic verified build nahi hai.`)
    } catch (e) { setBuilderLog(`Build request failed: ${e.message}. Provider ke output-token limit ya JSON support ko check karo.`) }
    finally { setBusy(false) }
  }
  const downloadProject = async () => {
    if (!projectFiles.length) return
    const zip = new JSZip()
    projectFiles.forEach(f => zip.file(f.path, f.content))
    const blob = await zip.generateAsync({ type: 'blob' })
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `${projectName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'navin-project'}.zip`; link.click(); URL.revokeObjectURL(link.href)
  }
  const deleteChat = (id) => { setChats(old => old.filter(c => c.id !== id)); if (currentChat === id) { setCurrentChat(null); setMessages([]) } }
  const submitAuth = async (e) => {
    e.preventDefault(); setAuthBusy(true); setAuthMessage('')
    try {
      if (authMode === 'otp') { await sendEmailOtp(email); setAuthMessage('OTP/link email par bhej diya gaya hai. Inbox aur spam check karo.') }
      else if (authMode === 'register') { const result = await signUpWithPassword(email, password); setAuthMessage(result.user?.identities?.length === 0 ? 'Is email par account pehle se ho sakta hai.' : 'Registration request complete. Email confirmation required ho sakta hai; inbox check karo.') }
      else { await signInWithPassword(email, password); setAuthMessage('Login successful.') }
    } catch (e) { setAuthMessage(e.message) } finally { setAuthBusy(false) }
  }
  const doSignOut = async () => { try { await signOut(); setSession(null); notify('Signed out.') } catch (e) { notify(e.message) } }
  const selectedContent = projectFiles.find(f => f.path === selectedFile)?.content || ''

  return <div className="app-shell">
    <aside className={`sidebar ${sidebarOpen || showMobileSidebar ? 'open' : ''}`}>
      <div className="brand"><Logo /><div><strong>Navin AI</strong><span>STUDIO</span></div><button className="icon-btn mobile-close" onClick={() => {setSidebarOpen(false);setShowMobileSidebar(false)}} aria-label="Close menu"><X size={17}/></button></div>
      <button className="new-chat" onClick={newChat}><Plus size={17}/> New chat <span>⌘ K</span></button>
      <div className="nav-label">WORKSPACE</div>
      <button className={`nav-item ${active==='chat'?'active':''}`} onClick={() => setActive('chat')}><MessageSquare size={17}/> AI Chat</button>
      <button className={`nav-item ${active==='builder'?'active':''}`} onClick={() => setActive('builder')}><Code2 size={17}/> Project Builder <span className="tiny-tag">BETA</span></button>
      <button className={`nav-item ${active==='image'?'active':''}`} onClick={() => setActive('image')}><ImageIcon size={17}/> Image Studio</button>
      <button className="nav-item" onClick={() => setSettingsOpen(true)}><Settings2 size={17}/> API Settings</button>
      <div className="history-heading"><span>RECENT CHATS</span><button className="icon-btn" onClick={newChat} aria-label="New conversation"><Plus size={15}/></button></div>
      <div className="history-list">{chats.map(chat => <div key={chat.id} className={`history-row ${currentChat===chat.id?'chosen':''}`}><button onClick={() => openChat(chat)} title={chat.title}><MessageSquare size={14}/><span>{chat.title}</span></button><button className="history-delete" onClick={() => deleteChat(chat.id)} aria-label="Delete chat"><Trash2 size={13}/></button></div>)}
        {!chats.length && <p className="empty-history">Your conversations will appear here.</p>}
      </div>
      <div className="sidebar-bottom">
        <div className="api-status"><span className={`status-dot ${settings.baseUrl && settings.model?'configured':''}`}/><div><strong>{settings.baseUrl && settings.model ? 'API configured' : 'API not configured'}</strong><span>{settings.baseUrl && settings.model ? settings.model : 'Add your provider details'}</span></div><button className="icon-btn" onClick={() => setSettingsOpen(true)} aria-label="Configure API"><Settings2 size={15}/></button></div>
        <button className="profile" onClick={() => session ? doSignOut() : setAuthOpen(true)}>{session ? <><div className="avatar">{(session.user.email||'N').slice(0,1).toUpperCase()}</div><div className="profile-text"><strong>{session.user.email}</strong><span>Click to sign out</span></div><LogOut size={15}/></> : <><div className="avatar"><LogIn size={16}/></div><div className="profile-text"><strong>Sign in / Register</strong><span>{supabaseConfigured?'Account sync available':'Configure Supabase first'}</span></div><ArrowUpRight size={15}/></>}</button>
      </div>
    </aside>
    {(sidebarOpen || showMobileSidebar) && <div className="sidebar-backdrop" onClick={() => {setSidebarOpen(false);setShowMobileSidebar(false)}}/>}
    <main className="main-panel">
      <header className="topbar"><div className="top-left"><button className="icon-btn mobile-menu" onClick={() => setShowMobileSidebar(true)} aria-label="Open menu"><Menu size={19}/></button><div className="breadcrumb">Workspace <span>/</span> <strong>{active==='chat'?'AI Chat':active==='builder'?'Project Builder':'Image Studio'}</strong></div></div><div className="top-actions"><span className="secure-label"><ShieldCheck size={14}/> Your provider, your choice</span><button className="settings-button" onClick={() => setSettingsOpen(true)}><Settings2 size={16}/> Settings</button></div></header>

      {active==='chat' && <section className="chat-page">
        {messages.length===0 ? <div className="welcome-wrap"><div className="welcome-orb"><Logo/></div><div className="eyebrow"><Sparkles size={13}/> YOUR AI WORKSPACE</div><h1>What are we <span>building today?</span></h1><p className="welcome-sub">Chat with your configured AI model, work through ideas, and turn plans into code.</p>
          <div className="prompt-grid">{starterPrompts.map(({icon:Icon,title,desc,prompt,action})=><button className="prompt-card" key={title} onClick={() => action ? setActive(action) : setDraft(prompt)}><span className="prompt-icon"><Icon size={18}/></span><span className="prompt-title">{title}</span><span className="prompt-desc">{desc}</span><ArrowUpRight className="prompt-arrow" size={15}/></button>)}</div>
          <div className="welcome-note"><span className="note-dot"/>{settings.baseUrl && settings.model ? `Ready to connect to ${settings.model}` : 'Connect your own API in Settings to start chatting'}</div>
        </div> : <div className="messages-wrap">{messages.map(m => <article className={`message ${m.role==='user'?'user-message':'assistant-message'}`} key={m.id}><div className="message-avatar">{m.role==='user' ? <span>{(session?.user?.email||'Y').slice(0,1).toUpperCase()}</span> : <Logo small/>}</div><div className="message-body"><div className="message-meta"><strong>{m.role==='user'?'You':'Navin AI'}</strong><span>{m.error?'Error':new Date(m.time||Date.now()).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span></div><div className={`message-content ${m.error?'error-text':''}`}>{m.content}</div>{m.role==='assistant' && <div className="message-tools"><button onClick={() => {navigator.clipboard?.writeText(m.content);notify('Copied to clipboard.')}}><Copy size={13}/> Copy</button><button onClick={() => speak(m.content)}><Volume2 size={13}/> Read aloud</button></div>}</div></article>)}{busy && <div className="thinking"><Logo small/><span className="typing-dots"><i/><i/><i/></span><span>{status || 'Waiting for API response…'}</span></div>}<div ref={bottomRef}/></div>}
        <div className="composer-zone"><div className="composer"><textarea value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => {if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}}} placeholder="Message Navin AI…" rows={1} aria-label="Message Navin AI"/><div className="composer-bottom"><div className="composer-tools"><button className={`tool-btn ${voiceOn?'voice-active':''}`} onClick={startVoice} title={voiceSupported?'Voice input':'Speech recognition unsupported'}><Mic size={16}/><span>{voiceOn?'Listening…':'Voice input'}</span></button><span className="model-indicator"><span className="status-dot"/> {settings.model || 'No model selected'}</span></div><button className="send-btn" disabled={!draft.trim()||busy} onClick={() => sendMessage()} aria-label="Send message">{busy?<LoaderCircle className="spin" size={17}/>:<Send size={17}/>}</button></div></div><div className="composer-disclaimer">AI responses may be incorrect. API usage and provider charges depend on your configured service.</div></div>
      </section>}

      {active==='image' && <section className="tool-page"><div className="tool-heading"><div className="tool-heading-icon purple"><ImageIcon size={22}/></div><div><div className="eyebrow">CREATIVE WORKSPACE</div><h1>Image <span>Studio</span></h1><p>Generate images through a compatible image API that you configure.</p></div></div><div className="image-layout"><div className="panel image-form"><label>Describe your image</label><textarea className="large-textarea" value={imagePrompt} onChange={e => setImagePrompt(e.target.value)} placeholder="A cinematic 3D render of a futuristic Indian city at blue hour, premium lighting…" rows={5}/><div className="helper-text">Detailed prompts usually give better results. Check your provider's supported size and response format.</div><button className="primary-button full" onClick={runImage} disabled={imageBusy||!imagePrompt.trim()}>{imageBusy?<><LoaderCircle className="spin" size={17}/> Requesting image…</>:<><Sparkles size={17}/> Generate image</>}</button>{imageError && <div className="inline-error">{imageError}</div>}</div><div className="panel image-preview">{imageBusy?<div className="image-loading"><div className="loader-orb"><Sparkles size={25}/></div><strong>Waiting for image provider</strong><span>Actual generation depends on your API response.</span></div>:imageResult?<><img className="generated-image" src={imageResult} alt={imagePrompt}/><a className="download-image" href={imageResult} download="navin-ai-image.png"><ArrowDownToLine size={15}/> Save image</a></>:<div className="image-empty"><div className="image-empty-icon"><ImageIcon size={30}/></div><strong>Your image will appear here</strong><span>No sample image is shown as a fake result.</span></div>}</div></div><div className="provider-hint"><CircleHelp size={16}/><div><strong>Provider setup required</strong><p>Set an image endpoint in API Settings. Image APIs differ in authentication and response format, so this client supports common URL/base64 responses only.</p><button className="text-button" onClick={() => setSettingsOpen(true)}>Configure image API <ArrowUpRight size={14}/></button></div></div></section>}

      {active==='builder' && <section className="tool-page builder-page"><div className="tool-heading"><div className="tool-heading-icon blue"><Code2 size={22}/></div><div><div className="eyebrow">CODE WORKSPACE</div><h1>Project <span>Builder</span></h1><p>Ask your AI provider to generate source files, review them, and export a ZIP.</p></div></div><div className="builder-grid"><div className="panel builder-controls"><label>Project name</label><input value={projectName} onChange={e => setProjectName(e.target.value)} placeholder="My project"/><label>What should it build?</label><textarea className="large-textarea" rows={7} value={builderPrompt} onChange={e => setBuilderPrompt(e.target.value)} placeholder="Describe the pages, functions, style, data flow, and technology you need…"/><div className="provider-hint compact"><CircleHelp size={15}/><p>Generated code is not automatically executed or tested. Review it before running or deploying.</p></div><button className="primary-button full" onClick={generateProject} disabled={busy||!builderPrompt.trim()}>{busy?<><LoaderCircle className="spin" size={16}/> Generating files…</>:<><WandSparkles size={16}/> Generate project files</>}</button>{builderLog && <div className="build-log"><Activity size={15}/><span>{builderLog}</span></div>}</div><div className="panel file-panel"><div className="file-panel-head"><div><FileCode2 size={16}/> <strong>Generated files</strong><span>{projectFiles.length}</span></div><button className="small-button" onClick={downloadProject} disabled={!projectFiles.length}><ArrowDownToLine size={14}/> Export ZIP</button></div>{projectFiles.length?<div className="file-browser"><div className="file-list">{projectFiles.map(file=><button key={file.path} className={selectedFile===file.path?'file-selected':''} onClick={() => setSelectedFile(file.path)}><FileCode2 size={14}/><span>{file.path}</span></button>)}</div><div className="code-preview"><div className="code-preview-head"><span className="window-dots"><i/><i/><i/></span><span>{selectedFile}</span><button onClick={() => {navigator.clipboard?.writeText(selectedContent);notify('File code copied.')}} aria-label="Copy file"><Copy size={14}/></button></div><pre><code>{selectedContent}</code></pre></div></div>:<div className="files-empty"><FolderPlus size={25}/><strong>No generated files yet</strong><span>Describe your project and request code generation.</span></div>}</div></div></section>}
    </main>

    {settingsOpen && <div className="modal-backdrop" onMouseDown={e => {if(e.target===e.currentTarget)setSettingsOpen(false)}}><div className="modal settings-modal"><div className="modal-header"><div className="modal-title-icon"><Settings2 size={19}/></div><div><h2>API Settings</h2><p>Connect your own compatible providers</p></div><button className="icon-btn" onClick={() => setSettingsOpen(false)} aria-label="Close settings"><X size={18}/></button></div><div className="modal-body"><div className="section-kicker">CHAT COMPLETION API</div><label>API Base URL</label><input value={settings.baseUrl} onChange={e => updateSetting('baseUrl',e.target.value)} placeholder="https://your-api.example.com"/><div className="field-note">Enter the base URL. The app adds /v1/chat/completions unless you provide the full endpoint.</div><label>API Key</label><div className="secret-input"><input type={showKey?'text':'password'} value={settings.apiKey} onChange={e => updateSetting('apiKey',e.target.value)} placeholder="Your API key (optional for some providers)"/><button onClick={() => setShowKey(v=>!v)} aria-label="Show or hide key">{showKey?<EyeOff size={16}/>:<Eye size={16}/>}</button></div><div className="field-note warning-note"><ShieldCheck size={13}/> Browser storage is not secure for production secrets. Use a server-side proxy for public deployment.</div><label>Model name</label><input value={settings.model} onChange={e => updateSetting('model',e.target.value)} placeholder="Exact model ID from your provider"/><div className="settings-two"><div><label>Temperature</label><input type="number" min="0" max="2" step="0.1" value={settings.temperature} onChange={e => updateSetting('temperature',e.target.value)}/></div><div><label>Max tokens</label><input type="number" min="1" max="32000" value={settings.maxTokens} onChange={e => updateSetting('maxTokens',e.target.value)}/></div></div><div className="section-kicker image-section-kicker">IMAGE API (OPTIONAL)</div><label>Image API endpoint</label><input value={settings.imageEndpoint} onChange={e => updateSetting('imageEndpoint',e.target.value)} placeholder="https://provider.example.com/v1/images/generations"/><label>Image model</label><input value={settings.imageModel} onChange={e => updateSetting('imageModel',e.target.value)} placeholder="Exact image model ID"/><button className="secondary-button full" onClick={runApiTest}><Activity size={16}/> Test chat API connection</button>{apiTest && <div className={`test-result ${apiTest.startsWith('Connected')?'success':''}`}>{apiTest}</div>}<div className="section-kicker image-section-kicker">AUTHENTICATION</div><div className="auth-status-row"><div><strong>Supabase email auth</strong><span>{supabaseConfigured?'Environment variables detected':'Not configured yet'}</span></div><button className="small-button" onClick={() => {setSettingsOpen(false);setAuthOpen(true)}}>Open login</button></div><p className="field-note">Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your deployment environment, then rebuild. Never use the service_role key in frontend code.</p></div><div className="modal-footer"><button className="secondary-button" onClick={() => {setSettings(DEFAULTS);setApiTest('');localStorage.removeItem('navin-settings')}}>Clear settings</button><button className="primary-button" onClick={() => {setSettingsOpen(false);notify('Settings saved in this browser.')}}><Check size={16}/> Save settings</button></div></div></div>}

    {authOpen && <div className="modal-backdrop" onMouseDown={e => {if(e.target===e.currentTarget)setAuthOpen(false)}}><div className="modal auth-modal"><div className="modal-header"><div className="modal-title-icon"><KeyRound size={19}/></div><div><h2>Account access</h2><p>Use your configured Supabase project</p></div><button className="icon-btn" onClick={() => setAuthOpen(false)} aria-label="Close login"><X size={18}/></button></div><div className="modal-body"><div className="auth-tabs"><button className={authMode==='login'?'selected':''} onClick={() => {setAuthMode('login');setAuthMessage('')}}>Login</button><button className={authMode==='register'?'selected':''} onClick={() => {setAuthMode('register');setAuthMessage('')}}>Register</button><button className={authMode==='otp'?'selected':''} onClick={() => {setAuthMode('otp');setAuthMessage('')}}>Email OTP/link</button></div>{!supabaseConfigured && <div className="inline-error">Supabase is not configured. Add the two VITE_SUPABASE_* variables and redeploy before using account features.</div>}<form onSubmit={submitAuth}><label>Email</label><input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/>{authMode!=='otp' && <><label>Password</label><input type="password" minLength="6" required value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters"/></>}<button className="primary-button full" type="submit" disabled={authBusy||!supabaseConfigured}>{authBusy?<><LoaderCircle className="spin" size={16}/> Working…</>:authMode==='login'?'Sign in':authMode==='register'?'Create account':'Send email OTP/link'}</button></form>{authMessage && <div className="test-result">{authMessage}</div>}<p className="field-note">Email confirmation and OTP delivery depend on your Supabase Auth settings and email provider configuration.</p></div></div></div>}
    {toast && <div className="toast"><Check size={16}/>{toast}</div>}
  </div>
}
export default App
