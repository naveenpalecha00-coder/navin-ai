# Navin AI Studio — Full Project Starter

A responsive React + Vite workspace for chat, code-file generation, image API integration, and optional Supabase authentication.

## Run locally
1. Install Node.js LTS.
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local URL shown in the terminal.

If PowerShell blocks `npm.ps1`, use Command Prompt (cmd) instead, or run `npm.cmd install` and `npm.cmd run dev`.

## Configure your own chat API
Open **Settings → API Settings** and enter:
- API Base URL (the app appends `/v1/chat/completions` unless the full endpoint is supplied)
- API key, if required by the provider
- Exact model ID
- Temperature and max tokens

Click **Test chat API connection**. Your provider must support the OpenAI-compatible chat-completions request/response shape and allow browser CORS. If it does not, create a server-side proxy.

## Image API
Set an image endpoint and model under Image API settings. This implementation supports common response shapes containing `data[0].url`, `data[0].b64_json`, `images[0].url`, or `images[0].b64_json`. Providers differ; adapt `src/lib/ai.js` to your provider's documented request and response format. Image editing of uploaded images is not included in this starter.

## Supabase email/password and email OTP/link
1. Create a Supabase project.
2. Configure Authentication providers and email delivery.
3. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to a local `.env` file or deployment environment.
4. Rebuild/redeploy the app.
5. Ensure email confirmation/redirect URLs are set correctly in Supabase.

Only use the public anon key in the browser. Never expose a Supabase service-role key.

## Deploy to Netlify
- Push this project to GitHub.
- Import the repository in Netlify.
- Build command: `npm run build`
- Publish directory: `dist`
- Add Supabase environment variables in the site's environment settings if using auth.

## Deploy to Vercel
- Import the GitHub repository in Vercel.
- Framework: Vite (normally auto-detected)
- Build command: `npm run build`
- Output directory: `dist`
- Add environment variables before building if using Supabase.

## Important limitations and security
This is a full starter codebase, not a hosted AI model or a complete production SaaS backend. You must configure your provider APIs and Supabase project. Chat history and API settings are currently stored in browser local storage. API keys stored in the browser can be exposed to anyone using developer tools; for public production deployment, route API requests through a backend that protects secrets, rate-limits usage, validates users, and logs abuse. Supabase RLS/database-backed cross-device chat history is not implemented. The builder asks the model to generate source files and exports those files; it does not run, compile, sandbox, or automatically verify generated code. Voice uses browser speech recognition and speech synthesis where available and is not a realtime AI voice-call system. Image generation requires a compatible provider; image editing/upload workflows and video generation are not implemented. Multi-agent orchestration and one-click deployment are not implemented.
